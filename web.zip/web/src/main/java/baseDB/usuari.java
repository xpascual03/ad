/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseDB;

import java.sql.*;

public class usuari {

    private Connection getConnection() throws SQLException {
        String url = "jdbc:derby://localhost:1527/pr2"; // canvia nom BD si cal
        String user = "pr2";    // el teu usuari MySQL
        String password = "pr2"; // la teva contrasenya
        return DriverManager.getConnection(url, user, password);
    }

    public boolean validarUsuario(String usuario, String password) {
        String sql = "SELECT * FROM usuarios WHERE id_usuario=? AND password=?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, usuario);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            return rs.next(); // True si hi ha coincidència
        } catch (SQLException e) {
            return false;
        }
    }
    
    public boolean insertarUsuario(String usuario, String password) {
    String sql = "INSERT INTO usuarios (nombre, password) VALUES (?, ?)";
    try (Connection con = getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
        
        ps.setString(1, usuario);
        ps.setString(2, password);
        int filas = ps.executeUpdate();
        return filas > 0;
    } catch (SQLException e) {
        return false;
    }
}

}
