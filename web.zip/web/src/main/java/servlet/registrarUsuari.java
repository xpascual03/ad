
package servlet;

import baseDB.usuari;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "RegistrarUsuari", urlPatterns = {"/registrarUsuari"})
public class registrarUsuari extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String usuario = request.getParameter("usuario");
        String password = request.getParameter("password");

        usuari dao = new usuari();
        boolean creado = dao.insertarUsuario(usuario, password);

        if (creado) {
            request.setAttribute("mensaje", "Usuari registrat correctament. Ara pots iniciar sessió.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "No s’ha pogut registrar l’usuari (potser ja existeix).");
            request.getRequestDispatcher("registrarUsuari.jsp").forward(request, response);
        }
    }
}
