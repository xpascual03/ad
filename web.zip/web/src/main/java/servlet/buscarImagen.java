package servlet;

import baseDB.imagenDAO;
import baseDB.Imagen;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "buscarImagen", urlPatterns = {"/buscarImagen"})
public class buscarImagen extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title    = request.getParameter("title");
        String keywords = request.getParameter("keywords");
        String author   = request.getParameter("author");

        // 🔧 Normalitzem els null a cadenes buides
        if (title == null) title = "";
        if (keywords == null) keywords = "";
        if (author == null) author = "";

        imagenDAO dao = new imagenDAO();
        List<Imagen> resultats = dao.buscarImagenes(title, keywords, author);

        request.setAttribute("resultats", resultats);
        request.getRequestDispatcher("buscarImagen.jsp").forward(request, response);
    }
}
