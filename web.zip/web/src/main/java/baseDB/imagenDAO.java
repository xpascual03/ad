package baseDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class imagenDAO {

    private String lastError = null;

    public String getLastError() {
        return lastError;
    }

    // Connexió a la BD (ajusta usuari/contrasenya segons el teu Derby o SGDB)
    private Connection getConnection() throws SQLException {
        String url = "jdbc:derby://localhost:1527/pr2"; 
        String user = "pr2";     
        String password = "pr2"; 
        return DriverManager.getConnection(url, user, password);
    }

    // Inserir una nova imatge
    public boolean insertarImagen(String title, String description, String keywords,
                                  String author, String creator,
                                  Date captureDate, Date storageDate, String filename) {
        lastError = null;

        String sql = "INSERT INTO IMAGE (TITLE, DESCRIPTION, KEYWORDS, AUTHOR, CREATOR, CAPTURE_DATE, STORAGE_DATE, FILENAME) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, keywords);
            ps.setString(4, author);
            ps.setString(5, creator);
            ps.setDate(6, captureDate);
            ps.setDate(7, storageDate);
            ps.setString(8, filename);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            lastError = e.getMessage() + " | SQLState=" + e.getSQLState() + " | ErrorCode=" + e.getErrorCode();
            return false;
        }
    }

    // Buscar imatges segons filtres opcionals
    public List<Imagen> buscarImagenes(String title, String keywords, String author, String creator) {
        List<Imagen> llista = new ArrayList<>();
        lastError = null;

        boolean hasFilter = (title != null && !title.isEmpty()) || (creator != null && !creator.isEmpty()) ||
                            (keywords != null && !keywords.isEmpty()) ||
                            (author != null && !author.isEmpty());

        StringBuilder sql;
        if (hasFilter) {
            sql = new StringBuilder("SELECT * FROM IMAGE WHERE 1=1");
            if (title != null && !title.isEmpty()) {
                sql.append(" AND TITLE LIKE ?");
            }
            if (keywords != null && !keywords.isEmpty()) {
                sql.append(" AND KEYWORDS LIKE ?");
            }
            if (author != null && !author.isEmpty()) {
                sql.append(" AND AUTHOR LIKE ?");
            }
            if (creator != null && !creator.isEmpty()) {
                sql.append(" AND CREATOR LIKE ?");
            }
        } else {
            sql = new StringBuilder("SELECT * FROM IMAGE");
        }

        try (Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql.toString())) {
           
            
            int idx = 1;
            if (hasFilter) {
                if (title != null && !title.isEmpty()) {
                    ps.setString(idx++, "%" + title + "%");
                }
                if (keywords != null && !keywords.isEmpty()) {
                    ps.setString(idx++, "%" + keywords + "%");
                }
                if (author != null && !author.isEmpty()) {
                    ps.setString(idx++, "%" + author + "%");
                }
                if (creator != null && !creator.isEmpty()) {
                    ps.setString(idx++, "%" + creator + "%");
                }
           
            }
            
            try (ResultSet rs = ps.executeQuery()) {
                int count = 0;
                while (rs.next()) {
                    count++;
                    System.out.println("Fila trobada: ID=" + rs.getInt("ID") +
                           " Title=" + rs.getString("TITLE") +
                           " Creator=" + rs.getString("CREATOR"));
                    Imagen img = new Imagen();
                    img.setId(rs.getInt("ID"));
                    img.setTitle(rs.getString("TITLE"));
                    img.setDescription(rs.getString("DESCRIPTION"));
                    img.setKeywords(rs.getString("KEYWORDS"));
                    img.setAuthor(rs.getString("AUTHOR"));
                    img.setCreator(rs.getString("CREATOR"));
                    img.setCaptureDate(rs.getDate("CAPTURE_DATE"));
                    img.setStorageDate(rs.getDate("STORAGE_DATE"));
                    img.setFilename(rs.getString("FILENAME"));

                    llista.add(img);
                }
                System.out.println("Files realment trobades: " + count);
            }
        } catch (SQLException e) {
            lastError = e.getMessage();
        }

        return llista;
    }


    // Més endavant: actualitzar imatge
    public boolean modificarImagen(Imagen img) {
        lastError = null;
        String sql = "UPDATE IMAGE SET TITLE=?, DESCRIPTION=?, KEYWORDS=?, AUTHOR=?, CAPTURE_DATE=?, FILENAME=? "
                   + "WHERE ID=? AND CREATOR=?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, img.getTitle());
            ps.setString(2, img.getDescription());
            ps.setString(3, img.getKeywords());
            ps.setString(4, img.getAuthor());
            ps.setDate(5, img.getCaptureDate());
            ps.setString(6, img.getFilename());
            ps.setInt(7, img.getId());
            ps.setString(8, img.getCreator());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            lastError = e.getMessage();
            return false;
        }
    }

    // Més endavant: eliminar imatge
    public boolean eliminarImagen(int id, String creator) {
        lastError = null;
        String sql = "DELETE FROM IMAGE WHERE ID=? AND CREATOR=?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.setString(2, creator);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            lastError = e.getMessage();
            return false;
        }
    }
}
