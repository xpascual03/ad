package servlet;

import baseDB.usuari;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "RegistrarUsuari", urlPatterns = {"/registrarUsuari"})
public class registrarUsuari extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String usuario = request.getParameter("usuario");
        String password = request.getParameter("password");

        usuari dao = new usuari();
        boolean creado = dao.insertarUsuario(usuario, password);

        if (creado) {
            // Redirigeix al login amb un missatge com a paràmetre GET
            response.sendRedirect("login.jsp?mensaje=Usuari+registrat+correctament");
        } else {
            // Si falla → es queda a la mateixa pàgina amb error
            request.setAttribute("error", "No s’ha pogut registrar l’usuari (potser ja existeix).");
            request.getRequestDispatcher("registrarUsuari.jsp").forward(request, response);
        }
    }
}

