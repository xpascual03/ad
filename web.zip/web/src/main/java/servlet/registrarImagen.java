package servlet;

import baseDB.imagenDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;

@WebServlet(name = "registrarImagen", urlPatterns = {"/registrarImagen"})
public class registrarImagen extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession ses = request.getSession(false);
        if (ses == null || ses.getAttribute("usuario") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String title       = request.getParameter("title");
        String description = request.getParameter("description");
        String keywords    = request.getParameter("keywords");
        String author      = request.getParameter("author");
        String creator     = request.getParameter("creator");
        String captureStr  = request.getParameter("capture_date");
        String filename    = request.getParameter("archivo");

        // Validació de la data obligatòria
        if (captureStr == null || captureStr.isEmpty()) {
            request.setAttribute("error", "La data de captura és obligatòria.");
            request.getRequestDispatcher("registrarImagen.jsp").forward(request, response);
            return;
        }

        Date captureDate = Date.valueOf(captureStr); // segur que no és null aquí
        Date storageDate = Date.valueOf(LocalDate.now());

        imagenDAO dao = new imagenDAO();
        boolean ok = dao.insertarImagen(title, description, keywords, author, creator,
                                        captureDate, storageDate, filename);

        if (ok) {
            request.setAttribute("mensaje", "Imatge registrada correctament!");
        } else {
            String why = (dao.getLastError() != null) ? dao.getLastError() : "Desconegut";
            request.setAttribute("error", "Error al registrar la imatge. " + why);
        }

        request.getRequestDispatcher("registrarImagen.jsp").forward(request, response);
    }
}
